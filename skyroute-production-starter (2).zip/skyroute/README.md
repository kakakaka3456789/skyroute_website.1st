# SKYROUTE

A Next.js affiliate flight-search starter with a PostgreSQL commission ledger and protected admin reporting.

## What is implemented

- Responsive EUR flight-search frontend.
- Search API with cheapest-first sorting.
- Explicit demo provider (fabricated fares; not bookable).
- Provider adapter interface for adding approved affiliate partners.
- Outbound click tracking model.
- Signed HMAC webhook example for partner booking events.
- Idempotent commission ledger event keys.
- Protected admin summary endpoint and dashboard.
- No card collection or ticket issuance on SKYROUTE.

## Critical status

This is a production-oriented **starter**, not a live flight-booking service. It does not include real inventory, a live affiliate contract, real provider credentials, or guaranteed 3% commission. Demo offers are clearly marked and cannot be booked. Do not advertise them as live fares.

## Requirements

- Node.js 20.9+
- PostgreSQL
- Affiliate account and approved partner API/deep-link/postback documentation

## Run locally

```bash
cp .env.example .env
# Edit DATABASE_URL and secrets
npm install
npx prisma generate
npx prisma db push
npm run dev
```

Open http://localhost:3000 and the admin page at http://localhost:3000/admin.

For admin, enter the `ADMIN_TOKEN` from your server-side `.env`. Never expose this token in client code, source control, or public deployment variables.

## Connecting a real affiliate provider

Implement `AffiliateProvider` in `src/lib/affiliate/provider.ts` (or create a provider-specific module) using the provider's official API and current documentation.

The adapter must:
1. Search only through authorized APIs.
2. Return normalized offers with total payable fare, currency, baggage, stops, itinerary, and expiry where available.
3. Preserve supplier/provider IDs and fare conditions.
4. Build a provider-approved deep link containing the click/sub-ID for attribution.
5. Revalidate an offer before redirect where the provider supports it.
6. Never claim a booking is confirmed based only on a click.

Provider URL formats and tracking parameters are not universal. Do not guess them. Store API credentials only in server-side environment variables.

## Webhook integration

`POST /api/partner/webhook` is an example normalized HMAC-SHA256 webhook. The partner's actual signature algorithm, headers, event names, and payload must be mapped to this endpoint based on its official documentation. Configure webhook retries and test duplicate delivery. The unique `eventKey` makes ledger insertion idempotent.

Do not accept unsigned public commission events. Do not trust client-submitted booking values or commission rates.

## Commission accounting

The partner-reported commission is authoritative. The 3% rate is a commercial target only. Confirm whether the contract pays 3% of ticket total, net fare, eligible revenue, or a fixed amount. Handle cancellations, refunds, chargebacks, reversals, currency conversion, minimum payout thresholds, and payout dates according to the partner contract.

Ledger entries are immutable event records. For a mature production system, add explicit adjustment/reversal entries rather than editing historical ledger rows, and reconcile the ledger against partner statements.

## Production hardening checklist

- Replace demo provider with one or more signed/approved provider integrations.
- Add rate limiting, bot protection, request logging, alerting and abuse monitoring.
- Add CSRF/origin protections where cookie-based auth is introduced.
- Use a proper admin identity provider, MFA, role-based access and audit logs; the simple bearer-token admin is for starter use only.
- Validate webhook IP/signature according to partner specification; add replay protection and timestamp validation.
- Add database migrations and backups.
- Add privacy/cookie consent, GDPR notices, retention and deletion workflows.
- Add monitoring for API latency, stale prices, affiliate attribution and payout discrepancies.
- Obtain legal review for German/EU intermediary, consumer, tax and privacy obligations.
- Verify partner availability, permitted markets, airline coverage, attribution window and actual commission terms before launch.

## Architecture

`Browser -> Next.js search API -> provider adapter -> normalized EUR offers -> cheapest-first list -> tracked affiliate redirect -> supplier checkout`

`Partner postback -> signature verification -> booking upsert -> idempotent commission ledger -> admin reporting`

SKYROUTE does not collect card data, take customer payment, or issue tickets in this affiliate model.
