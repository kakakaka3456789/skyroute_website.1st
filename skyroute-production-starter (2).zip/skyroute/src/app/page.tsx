"use client";

import { useState } from "react";
import type { FlightOffer } from "@/lib/types";

const money = (n: number, c: string) => new Intl.NumberFormat("en-DE", { style: "currency", currency: c }).format(n);
const duration = (m: number) => `${Math.floor(m / 60)}h ${m % 60}m`;

export default function Home() {
  const [origin, setOrigin] = useState("HAM");
  const [destination, setDestination] = useState("LHR");
  const [departureDate, setDepartureDate] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [adults, setAdults] = useState(1);
  const [cabin, setCabin] = useState("ECONOMY");
  const [offers, setOffers] = useState<FlightOffer[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function search(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError(""); setOffers([]);
    try {
      const res = await fetch("/api/flights/search", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ origin, destination, departureDate, returnDate: returnDate || undefined, adults, cabin, currency: "EUR" })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Flight search failed");
      setOffers(data.offers);
      if (data.demo) setError("Demo results only — these fares are illustrative and cannot be booked.");
    } catch (err) { setError(err instanceof Error ? err.message : "Something went wrong"); }
    finally { setLoading(false); }
  }

  async function book(offer: FlightOffer) {
    if (!offer.bookable) { setError("This is a demo offer. Connect an approved affiliate partner before enabling bookings."); return; }
    const res = await fetch("/api/affiliate/click", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ offerId: offer.id, provider: offer.provider, origin, destination, departureDate })
    });
    const data = await res.json();
    if (!res.ok) setError(data.error || "Could not create affiliate redirect");
    else window.location.assign(data.url);
  }

  return <main className="shell">
    <nav className="nav"><a className="brand" href="#"><span className="brandMark">✈</span> SKYROUTE</a><span className="navNote">YOUR WORLD. YOUR JOURNEY.</span></nav>
    <section className="hero">
      <div className="eyebrow">FLIGHTS • WORLDWIDE</div>
      <h1>Find your next<br/><em>way out there.</em></h1>
      <p>Compare available flight offers from our travel partners and find the lowest displayed fare.</p>
    </section>
    <section className="searchCard">
      <div className="cardHeading"><div><span className="eyebrow">PLAN YOUR TRIP</span><h2>Where to next?</h2></div><span className="currency">EUR €</span></div>
      <form onSubmit={search}>
        <div className="fieldGrid">
          <label>FROM<input required maxLength={3} value={origin} onChange={e=>setOrigin(e.target.value.toUpperCase())} placeholder="HAM"/></label>
          <label>TO<input required maxLength={3} value={destination} onChange={e=>setDestination(e.target.value.toUpperCase())} placeholder="LHR"/></label>
          <label>DEPARTURE<input required type="date" value={departureDate} onChange={e=>setDepartureDate(e.target.value)}/></label>
          <label>RETURN (OPTIONAL)<input type="date" min={departureDate} value={returnDate} onChange={e=>setReturnDate(e.target.value)}/></label>
          <label>TRAVELLERS<select value={adults} onChange={e=>setAdults(Number(e.target.value))}>{[1,2,3,4,5,6,7,8,9].map(n=><option key={n} value={n}>{n} adult{n>1?"s":""}</option>)}</select></label>
          <label>CLASS<select value={cabin} onChange={e=>setCabin(e.target.value)}><option value="ECONOMY">Economy</option><option value="PREMIUM_ECONOMY">Premium economy</option><option value="BUSINESS">Business</option><option value="FIRST">First class</option></select></label>
        </div>
        <button className="primary searchButton" disabled={loading}>{loading?"Searching…":"Search flights  →"}</button>
      </form>
    </section>
    {error && <div className="notice">{error}</div>}
    {offers.length>0 && <section className="results">
      <div className="resultsHeading"><div><span className="eyebrow">AVAILABLE PARTNER OFFERS</span><h2>Flight results</h2></div><span className="sortTag">↑ CHEAPEST FIRST</span></div>
      {offers.map(o=><article className="flight" key={o.id}>
        <div className="airline"><div className="airlineBadge">{o.airlineCode}</div><div><b>{o.airline}</b><small>{o.stops===0?"Direct":`${o.stops} stop`} · {duration(o.durationMinutes)}</small></div></div>
        <div className="route"><b>{o.origin}</b><span>→</span><b>{o.destination}</b></div>
        <div className="fare"><strong>{money(o.price,o.currency)}</strong><small>{o.baggage}</small></div>
        <button className="secondary" onClick={()=>book(o)}>{o.bookable?"Continue to partner":"Demo only"}</button>
      </article>)}
    </section>}
    <section className="trust"><div>✦ Partner-sourced offers</div><div>✦ Prices in EUR</div><div>✦ Secure partner checkout</div></section>
    <footer><b>SKYROUTE</b><span>We may earn a commission when you book through our partners. Partner availability, final prices and booking terms are confirmed on the supplier's website.</span></footer>
  </main>;
}
