import { NextResponse } from "next/server";
import { z } from "zod";
import { getProvider } from "@/lib/affiliate/provider";

const schema = z.object({
  origin: z.string().trim().min(3).max(3),
  destination: z.string().trim().min(3).max(3),
  departureDate: z.string().date(),
  returnDate: z.string().date().optional(),
  adults: z.number().int().min(1).max(9),
  cabin: z.enum(["ECONOMY", "PREMIUM_ECONOMY", "BUSINESS", "FIRST"]),
  currency: z.literal("EUR")
});

export async function POST(req: Request) {
  try {
    const input = schema.parse(await req.json());
    if (input.origin === input.destination) return NextResponse.json({ error: "Origin and destination must differ." }, { status: 400 });
    if (new Date(input.departureDate) < new Date(new Date().toISOString().slice(0, 10))) {
      return NextResponse.json({ error: "Departure date must be today or later." }, { status: 400 });
    }
    const provider = getProvider();
    const offers = await provider.search(input);
    offers.sort((a,b) => a.price - b.price);
    return NextResponse.json({ offers, currency: "EUR", sort: "price_ascending", demo: provider.name === "demo" });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Invalid search" }, { status: 400 });
  }
}
