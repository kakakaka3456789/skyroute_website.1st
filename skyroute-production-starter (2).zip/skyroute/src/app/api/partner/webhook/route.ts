import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { verifyHmac } from "@/lib/security";

/**
 * Example normalized postback endpoint.
 * Configure the provider to send the raw JSON body signed as HMAC-SHA256.
 * Adapt field mapping and signature headers to the provider's official spec.
 */
const eventSchema = z.object({
  eventId: z.string().min(1),
  bookingId: z.string().min(1),
  clickId: z.string().optional(),
  status: z.enum(["PENDING", "CONFIRMED", "CANCELLED", "REVERSED", "PAID"]),
  commissionAmount: z.number().nonnegative(),
  bookingValue: z.number().nonnegative().optional(),
  currency: z.string().length(3).default("EUR"),
  occurredAt: z.string().datetime().optional()
});

export async function POST(req: Request) {
  const raw = await req.text();
  const secret = process.env.PARTNER_WEBHOOK_SECRET;
  const signature = req.headers.get("x-partner-signature") || "";
  if (!secret || !signature || !verifyHmac(raw, signature, secret)) {
    return NextResponse.json({ error: "Invalid webhook signature" }, { status: 401 });
  }

  try {
    const event = eventSchema.parse(JSON.parse(raw));
    const click = event.clickId ? await prisma.affiliateClick.findUnique({ where: { clickId: event.clickId } }) : null;
    const booking = await prisma.affiliateBooking.upsert({
      where: { partnerBookingId: event.bookingId },
      create: {
        partnerBookingId: event.bookingId, clickId: click?.clickId,
        provider: click?.provider || "unknown", status: event.status,
        bookingValue: event.bookingValue, commissionAmount: event.commissionAmount,
        currency: event.currency, partnerReportedAt: event.occurredAt ? new Date(event.occurredAt) : new Date()
      },
      update: {
        status: event.status, commissionAmount: event.commissionAmount,
        bookingValue: event.bookingValue, partnerReportedAt: event.occurredAt ? new Date(event.occurredAt) : new Date()
      }
    });

    // Idempotent event ledger: duplicate event IDs cannot create duplicate entries.
    await prisma.commissionLedger.createMany({
      data: [{
        bookingId: booking.id, eventKey: event.eventId, eventType: event.status,
        amount: event.status === "CANCELLED" || event.status === "REVERSED" ? -event.commissionAmount : event.commissionAmount,
        currency: event.currency
      }],
      skipDuplicates: true
    });
    return NextResponse.json({ received: true });
  } catch {
    return NextResponse.json({ error: "Invalid event payload" }, { status: 400 });
  }
}
