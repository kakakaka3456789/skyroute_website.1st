import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  const token = process.env.ADMIN_TOKEN;
  if (!token || req.headers.get("authorization") !== `Bearer ${token}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const [clicks, bookings, pending, confirmed, paid, recent] = await Promise.all([
    prisma.affiliateClick.count(),
    prisma.affiliateBooking.count(),
    prisma.affiliateBooking.aggregate({ where: { status: "PENDING" }, _sum: { commissionAmount: true } }),
    prisma.affiliateBooking.aggregate({ where: { status: "CONFIRMED" }, _sum: { commissionAmount: true } }),
    prisma.affiliateBooking.aggregate({ where: { status: "PAID" }, _sum: { commissionAmount: true } }),
    prisma.affiliateBooking.findMany({ take: 20, orderBy: { createdAt: "desc" }, select: {
      partnerBookingId: true, provider: true, status: true, commissionAmount: true, currency: true, createdAt: true
    }})
  ]);
  return NextResponse.json({
    clicks, bookings,
    commissions: {
      pending: pending._sum.commissionAmount?.toString() || "0",
      confirmed: confirmed._sum.commissionAmount?.toString() || "0",
      paid: paid._sum.commissionAmount?.toString() || "0"
    },
    recent
  });
}
