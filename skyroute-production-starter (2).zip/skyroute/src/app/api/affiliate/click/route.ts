import { NextResponse } from "next/server";
import crypto from "node:crypto";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getProvider } from "@/lib/affiliate/provider";

const schema = z.object({
  offerId: z.string().min(1).max(160),
  provider: z.string().min(1).max(80),
  origin: z.string().length(3),
  destination: z.string().length(3),
  departureDate: z.string().date()
});

export async function POST(req: Request) {
  try {
    const input = schema.parse(await req.json());
    const provider = getProvider();
    if (provider.name === "demo" || input.provider !== provider.name) {
      return NextResponse.json({ error: "Live affiliate booking is not configured. Demo offers cannot be booked." }, { status: 503 });
    }
    // Production adapters must fetch/revalidate the offer server-side before redirecting.
    const clickId = crypto.randomUUID();
    const offer = (await provider.search({
      origin: input.origin, destination: input.destination, departureDate: input.departureDate,
      adults: 1, cabin: "ECONOMY", currency: "EUR"
    })).find(x => x.id === input.offerId);
    if (!offer) return NextResponse.json({ error: "Offer expired or unavailable. Search again." }, { status: 409 });
    const url = provider.bookingUrl(offer, clickId);
    const parsed = new URL(url);
    if (parsed.protocol !== "https:") return NextResponse.json({ error: "Partner URL must use HTTPS." }, { status: 500 });
    await prisma.affiliateClick.create({ data: {
      clickId, provider: provider.name, offerId: offer.id,
      origin: input.origin, destination: input.destination, departureDate: input.departureDate, currency: "EUR"
    }});
    return NextResponse.json({ url });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not create referral" }, { status: 400 });
  }
}
