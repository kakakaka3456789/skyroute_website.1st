import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SKYROUTE — Compare flights worldwide",
  description: "Compare flight offers from travel partners and find a fare that fits your trip."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
