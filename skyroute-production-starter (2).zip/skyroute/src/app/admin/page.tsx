"use client";
import { useState } from "react";

export default function Admin() {
  const [token,setToken] = useState("");
  const [data,setData] = useState<any>(null);
  const [error,setError] = useState("");
  async function load() {
    setError("");
    const r = await fetch("/api/admin/summary", { headers: { Authorization: `Bearer ${token}` }, cache: "no-store" });
    const d = await r.json();
    if (!r.ok) { setError(d.error || "Could not load dashboard"); setData(null); return; }
    setData(d);
  }
  return <main className="shell adminShell">
    <nav className="nav"><a className="brand" href="/">✈ SKYROUTE</a><span className="navNote">PRIVATE ADMIN</span></nav>
    <h1>Business dashboard</h1><p className="muted">Partner-reported activity and commission ledger.</p>
    <section className="searchCard">
      <label>ADMIN TOKEN<input type="password" value={token} onChange={e=>setToken(e.target.value)} autoComplete="current-password"/></label>
      <button className="primary" onClick={load}>Load dashboard</button>
      {error && <div className="notice">{error}</div>}
    </section>
    {data && <>
      <div className="adminGrid">
        <div className="metric"><small>Tracked clicks</small><b>{data.clicks}</b></div>
        <div className="metric"><small>Reported bookings</small><b>{data.bookings}</b></div>
        <div className="metric"><small>Pending commission</small><b>€{data.commissions.pending}</b></div>
        <div className="metric"><small>Confirmed commission</small><b>€{data.commissions.confirmed}</b></div>
        <div className="metric"><small>Paid commission</small><b>€{data.commissions.paid}</b></div>
      </div>
      <section className="searchCard"><h2>Recent bookings</h2><div className="tableWrap"><table><thead><tr><th>Partner booking</th><th>Partner</th><th>Status</th><th>Commission</th></tr></thead><tbody>
        {data.recent.map((b:any)=><tr key={b.partnerBookingId}><td>{b.partnerBookingId}</td><td>{b.provider}</td><td>{b.status}</td><td>{b.currency} {b.commissionAmount}</td></tr>)}
      </tbody></table></div></section>
    </>}
  </main>;
}
