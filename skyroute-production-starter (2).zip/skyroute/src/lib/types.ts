export type FlightOffer = {
  id: string;
  provider: string;
  airline: string;
  airlineCode: string;
  origin: string;
  destination: string;
  departureAt: string;
  arrivalAt: string;
  stops: number;
  durationMinutes: number;
  price: number;
  currency: string;
  baggage: string;
  bookingUrl?: string;
  bookable: boolean;
};

export type FlightSearch = {
  origin: string;
  destination: string;
  departureDate: string;
  returnDate?: string;
  adults: number;
  cabin: "ECONOMY" | "PREMIUM_ECONOMY" | "BUSINESS" | "FIRST";
  currency: string;
};
