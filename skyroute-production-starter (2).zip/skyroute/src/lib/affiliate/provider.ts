import type { FlightOffer, FlightSearch } from "@/lib/types";

export interface AffiliateProvider {
  name: string;
  search(input: FlightSearch): Promise<FlightOffer[]>;
  bookingUrl(offer: FlightOffer, clickId: string): string;
}

/**
 * Safe demo provider: fabricated offers and no real booking URL.
 * Replace with a provider adapter only after signing up and receiving API credentials.
 * Do not scrape airline websites or fabricate affiliate parameters.
 */
export class DemoProvider implements AffiliateProvider {
  name = "demo";

  async search(input: FlightSearch): Promise<FlightOffer[]> {
    const base = [
      { airline: "Lufthansa", code: "LH", price: 189, stops: 0, duration: 105, baggage: "Cabin bag included" },
      { airline: "British Airways", code: "BA", price: 164, stops: 1, duration: 245, baggage: "Cabin bag included" },
      { airline: "Qatar Airways", code: "QR", price: 492, stops: 1, duration: 510, baggage: "Checked baggage included" },
      { airline: "Emirates", code: "EK", price: 515, stops: 1, duration: 535, baggage: "Checked baggage included" }
    ];
    return base.map((x, i) => ({
      id: `demo-${i + 1}`,
      provider: this.name,
      airline: x.airline,
      airlineCode: x.code,
      origin: input.origin.toUpperCase(),
      destination: input.destination.toUpperCase(),
      departureAt: `${input.departureDate}T${String(7 + i * 3).padStart(2, "0")}:30:00`,
      arrivalAt: `${input.departureDate}T${String(9 + i * 3).padStart(2, "0")}:15:00`,
      stops: x.stops,
      durationMinutes: x.duration,
      price: x.price,
      currency: "EUR",
      baggage: x.baggage,
      bookable: false
    }));
  }

  bookingUrl(): string {
    throw new Error("Demo offers cannot be booked. Configure a real affiliate provider.");
  }
}

export function getProvider(): AffiliateProvider {
  // Add a provider-specific adapter here after reviewing its current API and contract.
  // Different partners have different search APIs, deep-link formats, attribution windows,
  // postbacks, commission rules and supported markets.
  return new DemoProvider();
}
