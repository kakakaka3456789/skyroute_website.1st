/**
 * Affiliate commission is partner-reported, not inferred from the ticket total.
 * 3% is a target commercial rate only. Use this helper only if the signed contract
 * explicitly defines a percentage of the reported eligible commission base.
 */
export function targetCommission(eligibleBase: number, rate = 0.03): number {
  if (!Number.isFinite(eligibleBase) || eligibleBase < 0) throw new Error("Invalid eligible base");
  if (rate < 0 || rate > 1) throw new Error("Invalid commission rate");
  return Math.round(eligibleBase * rate * 100) / 100;
}
